﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private int count=3;
        private void Vhod_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new TradeEntities())
                {
                    var user = db.User.FirstOrDefault(s => s.UserLogin == log.Text && s.UserPassword == pas.Text);
                    if (user != null)
                    {
                        var role = db.Role.FirstOrDefault(r => r.RoleID == user.UserRole);
                        switch (user.UserRole)
                        {
                            case 1:
                                UserSis u = new UserSis();
                                u.Show();
                                u.NameUser.Content = user.UserSurname;
                                u.SurUser.Content = user.UserName;
                                u.PatUser.Content = user.UserPatronymic;
                                this.Close();
                                break;
                            case 2:
                                Manager m = new Manager();
                                m.Show();
                                m.NameUser.Content = user.UserSurname;
                                m.SurUser.Content = user.UserName;
                                m.PatUser.Content = user.UserPatronymic;
                                this.Close();
                                break;
                            case 3:
                                Admin ad = new Admin();
                                ad.Show();
                                ad.NameUser.Content = user.UserSurname;
                                ad.SurUser.Content = user.UserName;
                                ad.PatUser.Content = user.UserPatronymic;
                                this.Close();
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Логин или пароль не верен");
                        count--;

                        MessageBox.Show("Осталось попыток" + " " + count.ToString());
                        if (count == 0)
                        {
                            count = 3;
                            Captcha cap = new Captcha();
                            cap.Show();
                        }

                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка подлкючения к БД");
            }

        }

        private void TovarButton_Click(object sender, RoutedEventArgs e)
        {
            ProductWindow t = new ProductWindow();
            t.Show();
        }
    }
}
