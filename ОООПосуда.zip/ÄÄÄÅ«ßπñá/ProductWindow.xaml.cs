﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        public ProductWindow()
        {
            InitializeComponent();
            LoadTovar();
        }

        private void ProductWindow1_Loaded(object sender, RoutedEventArgs e)
        {


        }

        private void LoadTovar()
        {
            using (var context = new TradeEntities())
            {
                var tovary = context.Product.AsQueryable();

                // Поиск
                if (!string.IsNullOrEmpty(Poisk.Text))
                {
                    tovary = tovary.Where(t => t.ProductName.Contains(Poisk.Text) || t.ProductDescription.Contains(Poisk.Text) || t.ProductManufacturer.Contains(Poisk.Text));
                }

                ProductTable.ItemsSource = tovary.ToList();
            }

        }
        private void Poisk_SelectionChanged(object sender, RoutedEventArgs e)
        {
            LoadTovar();
        }

    }
}
