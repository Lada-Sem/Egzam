﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для AddProd.xaml
    /// </summary>
    public partial class AddProd : Window
    {
        public AddProd()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Product data = new Product();
            data.ProductArticleNumber = art.Text;
            data.ProductName = name.Text;
            data.ProductDescription = opisanie.Text;
            data.ProductCategory = categ.Text;
            data.ProductManufacturer = proizv.Text;
            data.ProductCost = Convert.ToInt32(cost.Text);
            data.ProductDiscountAmount = (byte?)Convert.ToInt32(skid.Text);
            data.ProductQuantityInStock = Convert.ToInt32(qua.Text);
            data.ProductStatus = 1;

            using (var context = new TradeEntities())
            {
                context.Product.Add(data);
                context.SaveChanges();
            }
        }
    }
}
