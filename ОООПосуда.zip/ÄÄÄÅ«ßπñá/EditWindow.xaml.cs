﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        public EditWindow()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {

            Product data = ProductTable.SelectedItem as Product;
            if (data != null)
            {
                data.ProductArticleNumber = art.Text;
                data.ProductName = name.Text;
                data.ProductDescription = opisanie.Text;
                data.ProductCategory = categ.Text;
                data.ProductManufacturer = proizv.Text;
                data.ProductCost = Convert.ToInt32(cost.Text);
                data.ProductDiscountAmount = (byte?)Convert.ToInt32(skid.Text);
                data.ProductQuantityInStock = Convert.ToInt32(qua.Text);

                //  selectedТовар.Наличие_На_Складе = isInStock ? 1 : 0; // Устанавливаем значение Наличие

                try
                {
                    using (var context = new TradeEntities())
                    {
                        context.SaveChanges();
                    }
                    MessageBox.Show("Данные успешно сохранены.");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении данных: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для редактирования.");
            }
        }


        private bool isInStock = false;

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            isInStock = true;
        }

        private void EditWindow1_Loaded(object sender, RoutedEventArgs e)
        {
            using (var context = new TradeEntities())
            {
                var товары = context.Product.ToList();
                ProductTable.ItemsSource = товары;
            }
        }

        private void ProductTable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Product data = ProductTable.SelectedItem as Product;
            if (data != null)
            {
                art.Text =  data.ProductArticleNumber  ;
                name.Text = data.ProductName ;
                opisanie.Text = data.ProductDescription ;
                categ.Text = data.ProductCategory;
                proizv.Text =  data.ProductManufacturer ;
                cost.Text = data.ProductCost.ToString();
                skid.Text = data.ProductDiscountAmount.ToString();
                qua.Text = data.ProductQuantityInStock.ToString();
            }
        }
    }
}
