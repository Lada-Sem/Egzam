﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void addProduct_Click(object sender, RoutedEventArgs e)
        {
            AddProd ap = new AddProd();
            ap.Show();
        }

        private void AdminWindow_Loaded(object sender, RoutedEventArgs e)
        {
            using (var context = new TradeEntities())
            {
                var товары = context.Product.ToList();
                ProductTable.ItemsSource = товары;
            }
        }
       // private ICollectionView dataView;
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (ProductTable.SelectedItem != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить эту запись?", "Удаление записи", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    if (ProductTable.SelectedItem is Product selectedTovar)
                    {
                        var context = new TradeEntities();
                        var userToDelete = context.Product.FirstOrDefault(u => u.ProductArticleNumber == selectedTovar.ProductArticleNumber);

                        if (userToDelete != null)
                        {
                            context.Product.Remove(userToDelete);
                            context.SaveChanges();

                            MessageBox.Show("Запись успешно удалена.");


                            ProductTable.ItemsSource = context.Product.ToList();
                        }
                    }
                }
            }

            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            EditWindow ew = new EditWindow();
            ew.Show();
        }
    }
}
